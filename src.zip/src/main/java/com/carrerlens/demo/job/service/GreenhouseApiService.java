package com.carrerlens.demo.job.service;


import com.carrerlens.demo.job.dto.GreenhouseJobsResponse;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;

@Service
public class GreenhouseApiService {

    private final RestClient restClient;

    public GreenhouseApiService(RestClient restClient) {
        this.restClient = restClient;
    }

    public GreenhouseJobsResponse fetchJobs(String boardToken) {
        String url = "https://boards-api.greenhouse.io/v1/boards/" + boardToken + "/jobs?content=true";

        return restClient.get()
                .uri(url)
                .retrieve()
                .body(GreenhouseJobsResponse.class);
    }
}