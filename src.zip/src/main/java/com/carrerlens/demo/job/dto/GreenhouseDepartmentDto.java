package com.carrerlens.demo.job.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class GreenhouseDepartmentDto {
    private Long id;
    private String name;
}