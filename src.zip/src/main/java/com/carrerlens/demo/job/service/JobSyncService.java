package com.carrerlens.demo.job.service;




import com.carrerlens.demo.job.dto.GreenhouseDepartmentDto;
import com.carrerlens.demo.job.dto.GreenhouseJobItem;
import com.carrerlens.demo.job.dto.GreenhouseJobsResponse;
import com.carrerlens.demo.job.dto.GreenhouseOfficeDto;
import com.carrerlens.demo.job.entity.JobPostingRaw;
import com.carrerlens.demo.job.eumtype.JobStatus;
import com.carrerlens.demo.job.repository.JobPostingRawRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.stream.Collectors;

@Service
public class JobSyncService {

    private final GreenhouseApiService greenhouseApiService;
    private final JobPostingRawRepository jobPostingRawRepository;

    public JobSyncService(GreenhouseApiService greenhouseApiService,
                          JobPostingRawRepository jobPostingRawRepository) {
        this.greenhouseApiService = greenhouseApiService;
        this.jobPostingRawRepository = jobPostingRawRepository;
    }

    @Transactional
    public int syncRawJobs(String boardToken) {
        GreenhouseJobsResponse response = greenhouseApiService.fetchJobs(boardToken);

        if (response == null || response.getJobs() == null) {
            return 0;
        }

        int count = 0;

        for (GreenhouseJobItem item : response.getJobs()) {
            JobPostingRaw raw = jobPostingRawRepository
                    .findBySourceAndSourceJobId("greenhouse", item.getId())
                    .orElseGet(JobPostingRaw::new);

            raw.setSource("greenhouse");
            raw.setSourceJobId(item.getId());
            raw.setTitle(item.getTitle());
            raw.setCompanyName(item.getCompany_name());
            raw.setLocationName(item.getLocation() != null ? item.getLocation().getName() : null);
            raw.setJobUrl(item.getAbsolute_url());
            raw.setContentRaw(item.getContent());
            raw.setLanguageCode(item.getLanguage());
            raw.setUpdatedAtRaw(item.getUpdated_at());
            raw.setFirstPublishedRaw(item.getFirst_published());
            raw.setDepartmentsRaw(joinDepartments(item));
            raw.setOfficesRaw(joinOffices(item));
            raw.setStatus(JobStatus.OPEN);
            raw.setLastSeenAt(LocalDateTime.now());
            raw.setCollectedAt(LocalDateTime.now());

            jobPostingRawRepository.save(raw);
            count++;
        }

        return count;
    }

    private String joinDepartments(GreenhouseJobItem item) {
        if (item.getDepartments() == null) return null;

        return item.getDepartments().stream()
                .map(GreenhouseDepartmentDto::getName)
                .collect(Collectors.joining(", "));
    }

    private String joinOffices(GreenhouseJobItem item) {
        if (item.getOffices() == null) return null;

        return item.getOffices().stream()
                .map(GreenhouseOfficeDto::getName)
                .collect(Collectors.joining(", "));
    }
}