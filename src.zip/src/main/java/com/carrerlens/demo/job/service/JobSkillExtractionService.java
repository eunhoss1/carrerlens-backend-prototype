package com.carrerlens.demo.job.service;

import com.carrerlens.demo.job.entity.JobPostingNormalized;
import com.carrerlens.demo.job.entity.JobPostingRaw;
import com.carrerlens.demo.job.entity.JobPostingSkill;
import com.carrerlens.demo.job.entity.SkillTag;
import com.carrerlens.demo.job.repository.JobPostingNormalizedRepository;
import com.carrerlens.demo.job.repository.JobPostingSkillRepository;
import com.carrerlens.demo.job.repository.SkillTagRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

@Service
public class JobSkillExtractionService {

    private final JobPostingNormalizedRepository jobPostingNormalizedRepository;
    private final SkillTagRepository skillTagRepository;
    private final JobPostingSkillRepository jobPostingSkillRepository;

    public JobSkillExtractionService(JobPostingNormalizedRepository jobPostingNormalizedRepository,
                                     SkillTagRepository skillTagRepository,
                                     JobPostingSkillRepository jobPostingSkillRepository) {
        this.jobPostingNormalizedRepository = jobPostingNormalizedRepository;
        this.skillTagRepository = skillTagRepository;
        this.jobPostingSkillRepository = jobPostingSkillRepository;
    }

    @Transactional
    public int extractSkillsFromItJobs() {
        List<JobPostingNormalized> jobs = jobPostingNormalizedRepository.findByItJobTrue();

        int savedCount = 0;

        for (JobPostingNormalized job : jobs) {
            JobPostingRaw raw = job.getRawJob();
            String content = safeLower(raw.getContentRaw());
            String title = safeLower(raw.getTitle());

            Set<String> matchedSkills = extractSkillCodes(title + " " + content);

            for (String skillCode : matchedSkills) {
                SkillTag skillTag = findOrCreateSkillTag(skillCode);

                boolean exists = jobPostingSkillRepository.findByJobAndSkillTag(job, skillTag).isPresent();
                if (exists) {
                    continue;
                }

                JobPostingSkill jobPostingSkill = new JobPostingSkill();
                jobPostingSkill.setJob(job);
                jobPostingSkill.setSkillTag(skillTag);
                jobPostingSkill.setRequired(true);

                jobPostingSkillRepository.save(jobPostingSkill);
                savedCount++;
            }
        }

        return savedCount;
    }

    private Set<String> extractSkillCodes(String text) {
        Set<String> results = new LinkedHashSet<>();

        addIfContains(results, text, "REACT", "react");
        addIfContains(results, text, "TYPESCRIPT", "typescript", "type script");
        addIfContains(results, text, "JAVASCRIPT", "javascript");
        addIfContains(results, text, "NEXTJS", "next.js", "nextjs");
        addIfContains(results, text, "VUE", "vue", "vue.js");
        addIfContains(results, text, "ANGULAR", "angular");

        addIfContains(results, text, "JAVA", "java");
        addIfContains(results, text, "SPRING", "spring boot", "spring");
        addIfContains(results, text, "JPA", "spring data jpa", "jpa", "hibernate");
        addIfContains(results, text, "KOTLIN", "kotlin");

        addIfContains(results, text, "NODEJS", "node.js", "nodejs");
        addIfContains(results, text, "EXPRESS", "express");
        addIfContains(results, text, "PYTHON", "python");
        addIfContains(results, text, "DJANGO", "django");
        addIfContains(results, text, "FASTAPI", "fastapi");
        addIfContains(results, text, "FLASK", "flask");

        addIfContains(results, text, "MYSQL", "mysql");
        addIfContains(results, text, "POSTGRESQL", "postgresql", "postgres");
        addIfContains(results, text, "MONGODB", "mongodb");
        addIfContains(results, text, "REDIS", "redis");

        addIfContains(results, text, "AWS", "aws", "amazon web services");
        addIfContains(results, text, "GCP", "google cloud", "gcp");
        addIfContains(results, text, "AZURE", "azure");
        addIfContains(results, text, "DOCKER", "docker");
        addIfContains(results, text, "KUBERNETES", "kubernetes", "k8s");
        addIfContains(results, text, "TERRAFORM", "terraform");

        addIfContains(results, text, "GIT", "git");
        addIfContains(results, text, "GITHUB", "github");
        addIfContains(results, text, "CI_CD", "ci/cd", "continuous integration", "continuous delivery");
        addIfContains(results, text, "JENKINS", "jenkins");

        addIfContains(results, text, "LLM", "llm", "large language model");
        addIfContains(results, text, "PYTORCH", "pytorch");
        addIfContains(results, text, "TENSORFLOW", "tensorflow");
        addIfContains(results, text, "SPARK", "spark");
        addIfContains(results, text, "AIRFLOW", "airflow");

        return results;
    }

    private void addIfContains(Set<String> results, String source, String code, String... keywords) {
        for (String keyword : keywords) {
            if (source.contains(keyword)) {
                results.add(code);
                return;
            }
        }
    }

    private SkillTag findOrCreateSkillTag(String code) {
        return skillTagRepository.findByCode(code)
                .orElseGet(() -> {
                    SkillTag skillTag = new SkillTag();
                    skillTag.setCode(code);
                    skillTag.setDisplayName(toDisplayName(code));
                    return skillTagRepository.save(skillTag);
                });
    }

    private String toDisplayName(String code) {
        return switch (code) {
            case "REACT" -> "React";
            case "TYPESCRIPT" -> "TypeScript";
            case "JAVASCRIPT" -> "JavaScript";
            case "NEXTJS" -> "Next.js";
            case "VUE" -> "Vue";
            case "ANGULAR" -> "Angular";
            case "JAVA" -> "Java";
            case "SPRING" -> "Spring";
            case "JPA" -> "JPA";
            case "KOTLIN" -> "Kotlin";
            case "NODEJS" -> "Node.js";
            case "EXPRESS" -> "Express";
            case "PYTHON" -> "Python";
            case "DJANGO" -> "Django";
            case "FASTAPI" -> "FastAPI";
            case "FLASK" -> "Flask";
            case "MYSQL" -> "MySQL";
            case "POSTGRESQL" -> "PostgreSQL";
            case "MONGODB" -> "MongoDB";
            case "REDIS" -> "Redis";
            case "AWS" -> "AWS";
            case "GCP" -> "GCP";
            case "AZURE" -> "Azure";
            case "DOCKER" -> "Docker";
            case "KUBERNETES" -> "Kubernetes";
            case "TERRAFORM" -> "Terraform";
            case "GIT" -> "Git";
            case "GITHUB" -> "GitHub";
            case "CI_CD" -> "CI/CD";
            case "JENKINS" -> "Jenkins";
            case "LLM" -> "LLM";
            case "PYTORCH" -> "PyTorch";
            case "TENSORFLOW" -> "TensorFlow";
            case "SPARK" -> "Spark";
            case "AIRFLOW" -> "Airflow";
            default -> code;
        };
    }

    private String safeLower(String value) {
        return value == null ? "" : value.toLowerCase(Locale.ROOT);
    }
}